/* Creazione DB */

CREATE DATABASE `toysgroup`;

USE `toysgroup`;

CREATE TABLE `product` (
  `product_id` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(90) NOT NULL,
  `costo` decimal(10,2) NOT NULL,
  `descrizione` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`product_id`)
);

CREATE TABLE `region` (
  `region_id` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(90) NOT NULL,
  PRIMARY KEY (`region_id`)
);

CREATE TABLE `sales` (
  `sales_id` int NOT NULL AUTO_INCREMENT,
  `product_id` int NOT NULL,
  `region_id` int NOT NULL,
  `data` date NOT NULL,
  `quantita` int NOT NULL,
  PRIMARY KEY (`sales_id`),
  KEY `product_id_idx` (`product_id`),
  KEY `region_id_idx` (`region_id`),
  CONSTRAINT `product_id` FOREIGN KEY (`product_id`) REFERENCES `product` (`product_id`) ON UPDATE CASCADE,
  CONSTRAINT `region_id` FOREIGN KEY (`region_id`) REFERENCES `region` (`region_id`) ON UPDATE CASCADE
);

/* popolamento tabelle */

/* product */
LOCK TABLES `product` WRITE;
/*!40000 ALTER TABLE `product` DISABLE KEYS */;
INSERT INTO `product` VALUES 
(1,'paperella',5.00,'disponibile in 5 colori'),
(2,'soldatini',12.50,'set plastica verdi e grigi'),
(3,'barbie',59.99,'bambola per ragazze'),
(4,'lego',100.00,'spaceship'),
(5,'beyblade',20.00,'trottola glorificata');
/*!40000 ALTER TABLE `product` ENABLE KEYS */;
UNLOCK TABLES;

/* region */
LOCK TABLES `region` WRITE;
/*!40000 ALTER TABLE `region` DISABLE KEYS */;
INSERT INTO `region` VALUES 
(1,'italia'),
(2,'francia'),
(3,'giappone'),
(4,'stati_uniti'),
(5,'canada'),
(6,'cuba');
/*!40000 ALTER TABLE `region` ENABLE KEYS */;
UNLOCK TABLES;

/* sales */

LOCK TABLES `sales` WRITE;
/*!40000 ALTER TABLE `sales` DISABLE KEYS */;
INSERT INTO `sales` VALUES (1,4,1,'2019-10-24',1),
(2,1,3,'2020-09-06',10),
(3,3,5,'2020-01-20',2),
(4,4,1,'2019-12-01',1),
(5,4,2,'2023-08-27',1),
(6,4,3,'2020-10-15',1),
(7,4,4,'2024-05-02',1),
(8,4,5,'2022-06-09',1),
(9,4,6,'2024-01-04',5),
(10,2,4,'2022-07-04',10),
(11,2,4,'2023-07-06',1),
(12,3,2,'2024-05-24',1),
(13,1,6,'2022-02-02',3),
(14,2,3,'2024-03-29',1);
/*!40000 ALTER TABLE `sales` ENABLE KEYS */;
UNLOCK TABLES;

/* esercizi */


/* 1: Verificare che i campi definiti come PK siano univoci. */

INSERT INTO `toysgroup`.`product`
(`product_id`,
`nome`,
`costo`,
`descrizione`)
VALUES
(1,
'bicarbonato',
999.99,
'costoso');

INSERT INTO `toysgroup`.`region`
(`region_id`,
`nome`)
VALUES
(1,
'cambogia');

INSERT INTO `toysgroup`.`sales`
(`sales_id`,
`product_id`,
`region_id`,
`data`,
`quantita`)
VALUES
(1,
1,
1,
'2023-05-23',
1);


/* 2: Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno. */

SELECT product.nome, YEAR(sales.data) as anno, SUM(product.costo * sales.quantita) as 'totale per anno'
FROM product
JOIN sales ON sales.product_id = product.product_id
group by product.nome, anno;


/* 3: Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente.  */

SELECT YEAR(sales.data) as anno, SUM(product.costo * sales.quantita) as fatturato, region.nome as stato
FROM product
JOIN sales ON sales.product_id = product.product_id
JOIN region ON region.region_id = sales.region_id
group by stato, anno
order by anno desc, fatturato desc;


/* 4: Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato? */

SELECT product.nome, SUM(sales.quantita) as totale
FROM sales
JOIN product ON product.product_id = sales.product_id
group by product.product_id, product.nome
ORDER BY totale DESC
LIMIT 1;

/* 5: Rispondere alla seguente domanda: quali sono, se ci sono, i prodotti invenduti? Proponi due approcci risolutivi differenti. */

SELECT product.*, sales.*
FROM product
LEFT JOIN sales ON product.product_id = sales.product_id
WHERE quantita is null;

SELECT product.*, sales.*
FROM sales
RIGHT JOIN product ON product.product_id = sales.product_id
WHERE quantita is null;

SELECT product.*
FROM product
WHERE product.product_id NOT IN (
SELECT product_id FROM sales
);

/* 6: Esporre l’elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita più recente). */

SELECT product.nome, MAX(sales.data) as data 
FROM product
JOIN sales ON product.product_id = sales.product_id
group by product.nome;